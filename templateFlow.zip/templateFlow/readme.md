# HEADING for vfc-application example

<!-- (mandatory) Insert a description for the example flow. Describe the use case or its specialty. -->

<!-- Insert an example image -->
<!-- ![image](./doc/example.png) -->

## Prerequisites
<!-- (optional) Describe prerequisites other than VFC to make this flow work -->

## Setup & Configuration
<!-- (mandatory) Describe the necessary steps to get this flow running -->

1. Import the flow in Visual Flow Creator
2. ...
   
3.  Save the flow 

:cloud: :heavy_check_mark: You're ready ... - enjoy!


## How does this flow works
<!-- (optional) Describe the flow and how it works -->

## Result
<!-- (optional) Description on what the results are from this flow -->

## See also
<!-- (optional) Description on what the results are from this flow -->

<!-- - [:shopping_cart: MindSphere Store: IoT Extension](https://mindsphere.io/store) -->


